AUTO GLASS GROWTH — BRAND KIT

Use:
- auto-glass-growth-logo.svg — primary website/header logo
- auto-glass-growth-logo-white.svg — dark-background logo
- auto-glass-growth-logo-stacked.svg — stacked version
- auto-glass-growth-mark.svg — AG mark only
- favicon.svg — primary favicon
- favicon-32x32.png — browser fallback
- favicon-16x16.png — browser fallback
- apple-touch-icon.png — 180×180
- icon-192.png — app icon
- icon-512.png — app icon
- og-image.png — 1200×630 social sharing image
- site.webmanifest — sample manifest

Use the AG mark, not the full wordmark, for favicon/app-icon use.
SVG is preferred for header/footer because it stays crisp.
